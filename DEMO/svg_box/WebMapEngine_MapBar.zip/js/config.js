﻿
<!--

var strMapsvrUrl = "";

var transparencyLevel = 60;//透明度

// for bubble footer
var DirectionInfo = ''; //'<br><br><a href="">设为起点</a>&nbsp;&nbsp;<a href="">设为终点</a><br><a href="">行车路径</a>&nbsp;&nbsp;<a href="">公交换乘</a>';

var strLicenseKey = 3409;//密匙
//var strLicenseKey = 699;//密匙
//var strRemoteIP = "61.182.209.30";

//var bubbleX = 0; //-38;
//var bubbleY = 0;

var iToolTipStyle = 1; // 1 - for bubble, 0 - for conventional

// conventional tooltip style definition here
//var topColor = "#8080FF";
//var subColor = "#CCCCFF";
//var topColor = "#FFAA60";
//var subColor = "#FFFFCC";
var topColor = "#008ED6";
var subColor = "#DEF7FF";
var mapwidth = 600;
var mapheight = 480;
var xoffset = 0;
var yoffset = 0;


var MapBackgroundColor = "#EBEAE8";

-->
